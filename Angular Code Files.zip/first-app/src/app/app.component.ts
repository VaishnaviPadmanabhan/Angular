import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  disableBtn = false;
  main = 'Main';
  title = 'This is my First App';


  getTitle() {
    return this.title;
  }

  constructor() {
    setTimeout(() => {
      this.disableBtn = !this.disableBtn;
    },2000);
  }

  getClickFn(event: Event) {
    console.log(event);
    alert('Button is clicked!');
  }

  getText(event: Event) {
    this.title = (<HTMLInputElement>event.target).value;
  }
}
