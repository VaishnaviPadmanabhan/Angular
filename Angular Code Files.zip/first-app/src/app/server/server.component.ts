
import { Component } from '@angular/core';

@Component({
    selector: 'app-server',
    templateUrl: './server.component.html',
    //styleUrls: ['./server.component.css']
    styles: [`
        .onlineServer {
            color: red;
        }

        .offlineServer {
            color: green;
        }
    `]
})

export class ServerComponent{
    servers = [{
        serverName: 'Server1',
        serverStatus: 'online'
    },{
        serverName: 'Server2',
        serverStatus: 'offline'
    }];

    constructor(){

    }

    getColor(){
        return 'blue';
    }
}