import { Component, OnInit } from '@angular/core';
import { NavService } from '../nav.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  activated = false;

  constructor(private navservice: NavService) { }

  ngOnInit() {
    debugger;
    this.navservice.activatedEvent.subscribe((data)=>{
      debugger;
      this.activated = data;
    })
  }

  onActivateClick(){
    debugger;
    this.navservice.activatedEvent.subscribe((data)=>{
      debugger;
      this.activated = data;
    })
  }

}
