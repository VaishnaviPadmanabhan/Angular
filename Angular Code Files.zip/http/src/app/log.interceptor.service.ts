import { HttpInterceptor } from "@angular/common/http";

export class LogInterceptor implements HttpInterceptor{
    intercept(req, next){
        console.log('Logging the request');
        return next.handle(req);
    }
}