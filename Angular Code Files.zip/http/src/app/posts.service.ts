import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { catchError, map } from 'rxjs/operators';
import { Subject, throwError } from "rxjs";

@Injectable({
    providedIn: 'root'
})
export class PostsService {
    errorSubject = new Subject<string>();
    constructor(private http: HttpClient){

    }

    fetchPosts() {
        //this.isLoading = true;
        let headersList = new HttpHeaders();
        headersList = headersList.append('Custom-header1','Hello1');
        headersList = headersList.append('Custom-header2','Hello2');
        let paramsList = new HttpParams();
        paramsList = paramsList.append('custom1','key1');
        paramsList = paramsList.append('custom2','key2');
        debugger;
        return this.http.get('https://ng-http-7d579-default-rtdb.firebaseio.com/posts.json', {
          headers: headersList,
          params: paramsList
        }).
        pipe(map((responseData)=>{
          debugger;
          const postArray = [];
          for(const key in responseData){
            postArray.push({...responseData[key],id: key});
            
          }
          return postArray;
        }), catchError(errRes=>{
          return throwError(errRes);
        }));
    }

}