import { HttpInterceptor } from "@angular/common/http";



export class PostsInterceptor implements HttpInterceptor{
    intercept(req,next){
        debugger;
        let modifiedReq = req;
        //if(req.method === 'GET'){
            modifiedReq = req.clone({
                headers: req.headers.append('Auth', 'abc')
            })
        //}
        return next.handle(modifiedReq);
    }

}