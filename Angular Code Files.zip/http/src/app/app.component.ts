import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { PostsService } from './posts.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title= 'ng-complete-guide-update';
  loadedPosts = [];
  isLoading = false;
  error = null;

  constructor(private http: HttpClient, private postsService: PostsService) {}

  ngOnInit() {
    this.postsService.fetchPosts().subscribe((posts)=> {
      this.loadedPosts = posts;
    });
  }

  onCreatePost(postData: { title: string; content: string }) {
    // Send Http request
    this.http.post('https://ng-http-7d579-default-rtdb.firebaseio.com/posts.json', postData).subscribe((data)=> {
      console.log(data);
    })
  }

  onFetchPosts() {
    // Send Http request
    
    this.postsService.fetchPosts().subscribe((posts)=> {
      this.loadedPosts = posts;
    },error=>{
      this.postsService.errorSubject.next(error.message);
    });

    this.postsService.errorSubject.subscribe((errorData)=>{
      console.log('Log - ', errorData);
    })
  }

  onClearPosts() {
    // Send Http request
    this.http.delete("https://ng-http-7d579-default-rtdb.firebaseio.com/posts.json",{
      responseType: 'text'
    }).subscribe((data)=>{
      debugger;
      this.loadedPosts = [];
    })
  }

  
}
