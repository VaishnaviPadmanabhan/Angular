import { Component, OnInit, ViewChild } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  @ViewChild('form',{static: true}) form;

  ngOnInit(){
  }

  onSubmit() {
    console.log(this.form);
  }

  formReset(){
    this.form.reset();
  }

  suggestUserName() {
    /* this.form.setValue({
      'username': 'Vaishnavi',
      'email': '',
      'secret': 'pet'
    }) */

    this.form.form.patchValue({
      'username': 'Vaishnavi',
      'secret': 'pet'
    })
    console.log(this.form);
  }
}
