import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-scondcomponent',
  templateUrl: './secondcomponent.component.html',
  styleUrls: ['./secondcomponent.component.css']
})
export class Secondcomponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
