import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-firstcomponent',
  templateUrl: './firstcomponent.component.html',
  styleUrls: ['./firstcomponent.component.css']
})
export class Firstcomponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
