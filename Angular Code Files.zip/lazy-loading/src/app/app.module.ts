import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { Firstcomponent } from './firstcomponent/firstcomponent.component';
import { SecondModule } from './second.module';

@NgModule({
  declarations: [
    AppComponent,
    Firstcomponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    SecondModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
