import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { Secondcomponent } from "./secondcomponent/secondcomponent.component";

const routes: Routes = [
    {path: '', component: Secondcomponent}
]

@NgModule({
    declarations: [
        Secondcomponent
    ],
    imports: [
        RouterModule.forChild(routes)
    ], 
    exports:[
        Secondcomponent
    ]
})
export class SecondModule {

}