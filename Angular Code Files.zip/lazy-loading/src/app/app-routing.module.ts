import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

import { Firstcomponent } from './firstcomponent/firstcomponent.component';


const routes: Routes = [
  {path: '', component: Firstcomponent},
  {path: 'second', loadChildren: () => import('./second.module').then(m => m.SecondModule)}
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {preloadingStrategy: PreloadAllModules})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
