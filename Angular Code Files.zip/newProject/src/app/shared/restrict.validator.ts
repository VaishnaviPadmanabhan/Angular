import { FormControl } from '@angular/forms'

export function RestrictValidator(formControl: FormControl) {

    return new Promise((resolve,reject) =>{
        if(formControl.value === 'test@test.com'){
            resolve({restrict: true});
        } else {
            resolve(null);
        }
    })
    
    
} 