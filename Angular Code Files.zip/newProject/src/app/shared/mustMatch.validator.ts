import { FormGroup, ValidatorFn } from '@angular/forms';

export function MustMatch (controlName: string,matchingControlName: string): ValidatorFn{
   return (formGroup: FormGroup) => {
        const control = formGroup.controls[controlName];
        const matchingControl = formGroup.controls[matchingControlName];
       
        if(!control || !matchingControl){
            return null;
        }

        if(control.errors || matchingControl.errors){
            return null;
        }

        if(control.value === matchingControl.value){
            setTimeout(()=>{
                matchingControl.setErrors(null);
            },5000);
            
        } else {
            
            setTimeout(()=>{
                matchingControl.setErrors({mustMatch: true});
            },5000);
        }

    }
}
