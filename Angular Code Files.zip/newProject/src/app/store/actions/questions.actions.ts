import { Action, createAction, props } from '@ngrx/store';
import { question } from 'src/app/model/question.interface';

//NGRX8
export const loadData = createAction(
    '[Question List] Load Data'
)

export const loadSuccess = createAction(
    '[Question List] Load Data Success',
    props<{[questions: string]: question[]}>()
)

export const addQuestionData = createAction(
    '[Questions] Add Question Data',
    props<{newquestions: question}>()
)



//NGRX6
/* export class loadData implements Action {
    readonly type: 'LOAD_DATA'

    constructor(public payload: string){}
} */

