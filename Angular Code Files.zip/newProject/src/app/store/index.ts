import { question } from '../model/question.interface';
import * as fromRouter from '@ngrx/router-store';
import { routerStateUrl } from './reducers';

export interface AppState {
    questions: question[],
    loading: boolean,
    routerReducer: fromRouter.RouterReducerState<routerStateUrl>
}

export  * from './reducers';
export  * from './actions';
export  * from './effects';




