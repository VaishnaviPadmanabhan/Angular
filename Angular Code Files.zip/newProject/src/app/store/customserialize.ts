import { RouterStateSerializer } from '@ngrx/router-store';
import { routerStateUrl } from './reducers';
import { RouterStateSnapshot, ActivatedRouteSnapshot } from '@angular/router';

export class CustomSerialize implements RouterStateSerializer<routerStateUrl>{
    serialize(routerState: RouterStateSnapshot): routerStateUrl{
        const url = routerState.url;
        const queryParams = routerState.root.queryParams;
        const fragment = routerState.root.fragment;

        let state: ActivatedRouteSnapshot = routerState.root;
        while(state.firstChild){
            state = state.firstChild;
        }

        const params = state.params;

        return {
            url,
            queryParams,
            params,
            fragment
        }
    }
}