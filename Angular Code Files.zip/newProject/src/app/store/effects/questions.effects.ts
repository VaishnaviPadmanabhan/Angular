import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { loadData, loadSuccess } from '../actions/questions.actions';
import { switchMap,map, mergeMap } from 'rxjs/operators';
import { QuestionDataService } from 'src/app/question-data.service';

@Injectable()
export class questionsEffect {

    constructor(private action: Actions,private questionDataService: QuestionDataService){

    }

    loadQuestions = createEffect(() => this.action.pipe(
        ofType(loadData),
        mergeMap(()=> this.questionDataService.getAllQuestions()),
        map(questions => 
            
            loadSuccess({questions})
        )
    ))

    
}

