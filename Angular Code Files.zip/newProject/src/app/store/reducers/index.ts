import * as fromRouter from '@ngrx/router-store';
import { Params } from '@angular/router';
import { createFeatureSelector } from '@ngrx/store';

export interface routerStateUrl {
    url: string;
    params: Params;
    queryParams: Params;
    fragment: string;
}


export const getRouterState = createFeatureSelector<fromRouter.RouterReducerState<routerStateUrl>>('routerReducer');

export * from './questions.reducers';
