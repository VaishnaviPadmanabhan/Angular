import { Action, createReducer,on, createSelector, createFeatureSelector } from '@ngrx/store';
import { EntityState, createEntityAdapter, EntityAdapter } from '@ngrx/entity';

import { loadData, loadSuccess, addQuestionData } from '../actions/questions.actions';
import { question } from 'src/app/model/question.interface';

export interface questionInterface extends EntityState<question>{
}

export function sortfn(q1,q2){
    return q1.id - q2.id
}

export const adapter: EntityAdapter<question> = createEntityAdapter<question>({
    sortComparer: sortfn
});

export const initialState: questionInterface = adapter.getInitialState({ });

export const _reducers = createReducer(initialState,
    on(loadData, (state,action)=> {
        return state;
    }),
    on(loadSuccess, (state,action) => {
        /* const data = action.questions;
        return {
            ...state,
            data
        } */
        return adapter.addAll(action.questions,{...state});
    }),
    on(addQuestionData, (state,action) => {
        return adapter.addOne(action.newquestions,{...state});
    })

)

export function reducers(state,actions: Action){    
    return _reducers(state,actions);
}

export const selectQuestionState = createFeatureSelector<questionInterface>("questions");

export const {
    selectAll,
    selectIds,
    selectEntities,
    selectTotal
} = adapter.getSelectors();

export const allQuestions = createSelector(selectQuestionState,selectAll);

export const questionEntities = createSelector(selectQuestionState,selectEntities);

export const nextId = createSelector(selectQuestionState,selectIds, (selectIds) => selectIds.ids.length);


 










