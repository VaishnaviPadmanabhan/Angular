import { Component, OnInit, Input, ViewEncapsulation, ContentChild, SimpleChange } from '@angular/core';
import { Observable,of } from 'rxjs';
import { QuestionDataService } from '../question-data.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Store, select } from '@ngrx/store';

import { AppState, getRouterState  } from '../store';
import { loadData } from '../store/actions/questions.actions';
import { allQuestions } from '../store/reducers/questions.reducers';
import { question } from '../model/question.interface';

@Component({
  selector: 'app-questions-list',
  templateUrl: './questions-list.component.html',
  styleUrls: ['./questions-list.component.css']
})

export class QuestionsListComponent implements OnInit {
  questions: Observable<question[]>;
  editScreen: boolean = false;
  editId: number;

  constructor(private dataService: QuestionDataService,
              private router: Router,
              private activeRoute: ActivatedRoute,
              private store: Store<AppState>) {

     this.store.dispatch(loadData());
  }

  ngOnInit(){    
    this.questions = this.store.pipe(select(allQuestions));   
  }

  onLinkClick(id){
       
    this.editScreen = true;
    this.editId = id;
    const editVal = ((id == 0) ? 1 : 0)
    this.router.navigate([id],{relativeTo: this.activeRoute, queryParams: {edit: editVal}, queryParamsHandling: 'merge',fragment: '123'});
  }
}
