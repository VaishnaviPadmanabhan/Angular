import { Component, ViewEncapsulation, ViewChild, SimpleChange } from '@angular/core';
import { QuestionsComponent } from './questions/questions.component';
import { QuestionDataService } from './question-data.service';
import { LogService } from './log.service';
import { question } from './model/question.interface';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class AppComponent {
  title = 'Interview Questions';
  questions: question[] = [];

  constructor(private dataService: QuestionDataService) {

  }

  ngOnInit(){
    //this.questions = this.dataService.questions;
  }

  newQA(qaObj: question){
    this.questions.push(qaObj);
  }
}
