import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { RouterModule, Routes } from "@angular/router";
import { MatButtonModule, MatSelectModule, MatCardModule, MatExpansionModule, MatDividerModule, MatIconModule, MatMenuModule, MatToolbarModule, MatInputModule, MatFormFieldModule, MatProgressSpinnerModule} from '@angular/material';

import { QuestionsListComponent } from "./questions-list/questions-list.component";
import { QuestionsComponent } from "./questions/questions.component";
import { SingleQuestionComponent } from "./single-question/single-question.component";
import { AuthService } from "./auth.service";
import { HomeComponent } from "./home/home.component";


const routes: Routes = [
    {path: '',  component: HomeComponent,children:[
        {path: 'quesans', component: QuestionsListComponent, children:[
            {path: ':id', component: SingleQuestionComponent, resolve:{data: AuthService}}
        ]},
        {path: 'newquesans', component: QuestionsComponent}
    ]}
    
]

@NgModule({
    declarations: [
        HomeComponent,
        QuestionsComponent,
        QuestionsListComponent,
        SingleQuestionComponent
    ],
    imports:[
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        MatExpansionModule,
        MatDividerModule,
        MatIconModule,
        MatMenuModule,
        MatToolbarModule,
        MatFormFieldModule,
        MatInputModule,
        MatButtonModule,
        MatCardModule,
        MatSelectModule,
        RouterModule.forChild(routes)
    ],
    providers: [AuthService], 
    exports: [
        HomeComponent,
        QuestionsComponent,
        QuestionsListComponent,
        SingleQuestionComponent
    ]

})

export class QuestionModule {

}