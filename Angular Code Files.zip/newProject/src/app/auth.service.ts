import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router, CanActivateChild, CanDeactivate, Resolve } from '@angular/router';
import { Observable } from 'rxjs';
import { LoginDataService } from './login/login-data.service';
import { QuestionDataService } from './question-data.service';


@Injectable() 
export class AuthService implements CanActivate,CanActivateChild,CanDeactivate<Observable<boolean> | Promise<boolean> | boolean>, Resolve<any>{

    constructor(private loginDataService: LoginDataService, 
                private router: Router,
                private dataService: QuestionDataService){

    }

    canActivate(route: ActivatedRouteSnapshot,
        state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean{
            /* if(this.loginDataService.isAuth()){
                debugger;
                return true;
            } else {
                //return false;
                this.router.navigate(['/home','quesans']);
            } */
            return true;
        
    }

    canActivateChild(route: ActivatedRouteSnapshot,
        state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean{
            return this.canActivate(route,state);
        
    }

    canDeactivate(component): Observable<boolean> | Promise<boolean> | boolean{
        return component.checkChange();
    }

    resolve(route: ActivatedRouteSnapshot,
            state: RouterStateSnapshot){
        return this.dataService.getQuestions(+route.params['id']);

    }
   
}