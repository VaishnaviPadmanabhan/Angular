import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { LoginDataService, AuthData } from './login-data.service';
import { Observable, Subscription } from 'rxjs';
import { LoginModel } from './login-model.model';
import { FormGroup, FormControl, Validators, FormBuilder, FormArray } from '@angular/forms';

import { MustMatch } from '../shared/mustMatch.validator';
import { RestrictValidator } from '../shared/restrict.validator';
import { UserModel } from './user-model.model';

@Component({
  selector: 'app-login',
  templateUrl: './login-reactive.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit,OnDestroy {
  @ViewChild('loginForm',{static: true}) loginForm;
  isLoggedIn: boolean = false;
  error: string = null;
  isLoading: boolean = false;
  login = new LoginModel('test@test.com');
  userSub: Subscription;

  auth: Observable<AuthData>;

  reactiveLoginForm: FormGroup;


  constructor(private loginDataService: LoginDataService,
              private router: Router,
              private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.loginDataService.user.next(null);
    this.userSub = this.loginDataService.user.subscribe(user =>{
      console.log(user);
    })

    /* this.reactiveLoginForm = new FormGroup({
      'email': new FormControl(null,[Validators.required]),
      'password': new FormControl(null,[Validators.required]),
      'confirmpassword': new FormControl(null,[Validators.required]),
      'role': new FormControl(null,[Validators.required])
    },
      MustMatch('password', 'confirmPassword')
    
    ); */

   this.reactiveLoginForm = this.formBuilder.group({
      login: this.formBuilder.group({
        email: [null,[Validators.required],RestrictValidator],
        password: [null,[Validators.required]]
      }),
      confirmpassword: [null,[Validators.required]],
      role: [null,[Validators.required]],
      department: this.formBuilder.array([])
    },{
      validator: MustMatch('password', 'confirmpassword')
    })

    this.reactiveLoginForm.statusChanges.subscribe(state =>{
    })

    this.reactiveLoginForm.get('login.email').statusChanges.subscribe(email=>{
    })

    
  }

  addDept(){
    const deptControl = this.formBuilder.control(null);
    (<FormArray>this.reactiveLoginForm.get('department')).push(deptControl);
  }

  ngOnDestroy(){
    this.userSub.unsubscribe();
  }

  get department(){
    return (<FormArray>this.reactiveLoginForm.get('department')).controls;
  }

  formSubmit(){
    this.isLoading = true;
    if(this.isLoggedIn){
      this.auth = this.loginDataService.signin({
        email: this.reactiveLoginForm.value.login.email,
        password: this.reactiveLoginForm.value.login.password
      })      
    }
    else {
      this.auth = this.loginDataService.signup({
        email: this.reactiveLoginForm.value.login.email,
        password: this.reactiveLoginForm.value.login.password,
        role: this.reactiveLoginForm.value.role
      })
    }   

    this.auth.subscribe(
      res => {
        if(this.isLoggedIn){
            this.isLoading = false;
            this.router.navigate(['/home','quesans'])
        } else {          
            this.loginDataService.addRoles(this.reactiveLoginForm.value).subscribe(resData => {
            this.isLoading = false;
            this.router.navigate(['/home','quesans'])
          })
        }         
      },
      err => {
        this.isLoading = false;
        this.error = err;
      }
    ); 
  
  }

  resetForm(formData){
    formData.form.reset();
  }

  onSwithchMode(){
    this.isLoggedIn = !this.isLoggedIn;
  }

}
