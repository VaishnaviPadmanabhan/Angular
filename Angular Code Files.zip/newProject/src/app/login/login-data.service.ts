import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

import { catchError, tap } from 'rxjs/operators';
import { throwError, Subject, BehaviorSubject } from 'rxjs';
import { UserModel } from './user-model.model';

export interface AuthData {
     email: string;
     expiresIn: string;
     idToken: string;
     kind?: string;
     localId: string;
     refreshToken: string;
     registered?: boolean;
}

@Injectable()
export class LoginDataService {

  constructor(private router: Router,
             private http: HttpClient){
  }
  
  enteredLogin: {email: string,idToken: string};
  user = new BehaviorSubject<UserModel>(null);

   isAuth(){
      this.http.get('https://new-project-b3770.firebaseio.com/roles.json').subscribe(res =>{
          return true;
      }, err => {
          return false;
      })
   }

   signin(obj){     
      return this.http.post<AuthData>('https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=AIzaSyDEFDkEVszDNEzDmlJGBm7LdiyJya_PtLM',{
          email: obj.email,
          password: obj.password,
          returnSecureToken: true
      }).pipe(catchError(this.errorHandler), tap(res => {
          this.handleAuthenticate(res.email,res.localId,res.idToken,res.expiresIn,res.refreshToken);
      }))
   }

   private handleAuthenticate(email,localId,idToken,expiresIn,refreshToken){
     const expireDate = new Date(new Date().getTime() + +expiresIn * 1000);
     const user = new UserModel(
          email,
          idToken,
          localId,
          refreshToken,
          expireDate
     );
     this.enteredLogin = {email,idToken};
     this.user.next(user);
   }

   signup(obj){
      return this.http.post<AuthData>('https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=AIzaSyDEFDkEVszDNEzDmlJGBm7LdiyJya_PtLM',{
          email: obj.email,
          password: obj.password,
          returnSecureToken: true
      }).pipe(catchError(this.errorHandler),tap(res => {
          this.handleAuthenticate(res.email,res.localId,res.idToken,res.expiresIn,res.refreshToken);
      }))
   }

   addRoles(obj){
     return this.http.post('https://new-project-b3770.firebaseio.com/roles.json',{email: obj.email,role: obj.role})
   }

   errorHandler(errorRes){
     let errorMessage = 'An error has occurred!';
     if(!errorRes.error || !errorRes.error.error){
          return throwError(errorMessage);
     }
     switch(errorRes.error.error.message) {
         case 'INVALID_PASSWORD':
               errorMessage = 'Pasword is incorrect.Check and retry!';
               break;
         case 'EMAIL_EXISTS':
              errorMessage = 'The email already exists!';
              break;
         case "MISSING_EMAIL":
               errorMessage = 'Email is not valid!';
               break;
     }
    return throwError(errorMessage);
   }
}
