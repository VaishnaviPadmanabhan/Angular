export class LoginModel {
    constructor(
      public email?: string,
      public password?: string,
      public confirmpassword?: string,
      public role?: string
    ) {}
  }