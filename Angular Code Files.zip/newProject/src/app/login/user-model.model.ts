export class UserModel {
    constructor(public email: string,private _token: string,public localId,private _idToken,private _expiresIn: Date){
    }
    get token(){
        if(!this._expiresIn || new Date()> this._expiresIn){
            return null;
        }
        return this._token;
    }
}