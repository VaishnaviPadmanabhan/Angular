import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { NgModule } from '@angular/core';
import { ErrorComponent } from './error/error.component';

const route: Routes = [
    {path: '', redirectTo: 'login', pathMatch: 'full'},
    {path: 'login', component: LoginComponent},
    {path: 'home', loadChildren: ()=> import('./question.module').then(m=> m.QuestionModule)},    
    {path: 'error', component: ErrorComponent, data: {message: 'Error has occurred. Please try after sometime.'}},
    {path: '**', redirectTo: 'error'}
]

@NgModule({
    imports:[
        RouterModule.forRoot(route)
    ],
    exports:[
        RouterModule
    ]
})

export class AppRoutingModule {
    

}