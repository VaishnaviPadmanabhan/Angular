import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { MatButtonModule, MatSelectModule, MatCardModule, MatExpansionModule, MatDividerModule, MatIconModule, MatMenuModule, MatToolbarModule, MatInputModule, MatFormFieldModule, MatProgressSpinnerModule} from '@angular/material';

import { AppComponent } from './app.component';
import { QuestionDataService } from './question-data.service';
import { LoginDataService } from './login/login-data.service';
import { LoginComponent } from './login/login.component';
import { AppRoutingModule } from './app-routing.module';
import { AuthService } from './auth.service';
import { LogService } from './log.service';
import { ErrorComponent } from './error/error.component';

import { MustMatchDirective } from './shared/mustMatch.directive';

import { StoreModule } from '@ngrx/store';
import { reducers } from './store/reducers/questions.reducers';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { EffectsModule } from '@ngrx/effects';
import { questionsEffect } from './store/effects/questions.effects';
import { StoreRouterConnectingModule, RouterStateSerializer, routerReducer } from '@ngrx/router-store';
import { CustomSerialize } from './store/customserialize';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    ErrorComponent,
    MustMatchDirective
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    ReactiveFormsModule,
    FormsModule,
    MatExpansionModule,
    MatDividerModule,
    MatIconModule,
    MatMenuModule,
    MatToolbarModule,
    AppRoutingModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatCardModule,
    MatSelectModule,
    HttpClientModule,
    MatProgressSpinnerModule,
    StoreModule.forRoot({questions: reducers,routerReducer: routerReducer}),
    StoreDevtoolsModule.instrument({ maxAge: 25 }),
    EffectsModule.forRoot([questionsEffect]),
    StoreRouterConnectingModule.forRoot()
  ],
  providers: [
    QuestionDataService,
    LogService,
    LoginDataService,
    AuthService,
    {
      provide: RouterStateSerializer,
      useClass: CustomSerialize
    }
    
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }

