import { Component, Output, EventEmitter, ViewChild } from '@angular/core';
import { map } from 'rxjs/operators';
import { Router, ActivatedRoute } from '@angular/router';

import { QuestionDataService } from '../question-data.service';
import { question } from '../model/question.interface';
import { Store, select } from '@ngrx/store';
import * as fromStore from '../store';

@Component({
    selector: 'app-questions',
    templateUrl: './questions.component.html',
    styleUrls: ['./questions.component.css']
})

export class QuestionsComponent{
  /* @ViewChild('questionRef',{static: false}) question;
  @ViewChild('ansRef',{static: false}) answer; */
  id: number;

  @Output() qAObj= new EventEmitter<question>();

  constructor(private dataService: QuestionDataService,
              private router: Router,
              private activeRoute: ActivatedRoute,
              private store: Store<fromStore.AppState>) {

  }

  ngOnInit(){
    this.store.pipe(select(fromStore.nextId)).subscribe(res => this.id = res+1)
  }

  submitQA(form) {
    const formData: question = form.form.value;
    this.store.dispatch(fromStore.addQuestionData({newquestions: formData}));
    this.router.navigate(['/home','quesans'],{relativeTo: this.activeRoute}); 

  }

  cancel(){
    this.router.navigate(['newquesans']); 
  }
}
