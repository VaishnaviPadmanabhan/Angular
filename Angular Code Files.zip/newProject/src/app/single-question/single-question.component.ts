import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { exhaustMap, concatMap, switchMap, map } from 'rxjs/operators';
import { Store } from '@ngrx/store';

import { QuestionDataService } from '../question-data.service';
import { question } from '../model/question.interface';
import { getRouterState, questionEntities, AppState } from '../store';

@Component({
  selector: 'app-single-question',
  templateUrl: './single-question.component.html',
  styleUrls: ['./single-question.component.css']
})
export class SingleQuestionComponent implements OnInit {
  question: question;
  questionId: number;
  saved: boolean = false;
  tadisable: boolean = false;
  edited: boolean = false;
  
  constructor(private router: Router,
            private activeRoute: ActivatedRoute,
            private dataService: QuestionDataService,
            private store: Store<AppState>) { }

  @ViewChild('textarea',{static: true}) textarea;

  ngOnInit() {
    this.tadisable = true;

    this.activeRoute.fragment.subscribe(
      (params)=>{
       //console.log(params);
      }
    )

    this.store.select(getRouterState).pipe(switchMap((ob1Val) => {
      return this.store.select(questionEntities).pipe(map((ob2Val) => ob2Val[+ob1Val.state.params.id+1]));
    }))
    .subscribe((mappedVal) => {
        this.question = mappedVal;
    });
    
  }


  onSave(){
      this.dataService.questions[this.questionId].answer = this.textarea.nativeElement.value;
      this.saved = true;
  }

  checkChange(){
    
      if(this.question.answer != this.textarea.nativeElement.value && !this.saved) {
          let conVal = confirm('Do you want to Save the changes before Leaving?');
          if(conVal == true) {
            this.onSave() 
          }
          return conVal;
      } else {
         
         return true;
      }
  }

  onEdit(){
    this.store.select(getRouterState).subscribe(res => {
      +res.state.queryParams.edit == 1 ? this.tadisable = true : this.tadisable = false 
    })

    if(this.tadisable){
      alert('This question cant be edited!');
    }

    this.edited = true;
  }

}
