export interface question {
    id: number;
    question: string;
    answer: string;
}