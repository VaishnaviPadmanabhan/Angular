
import { LogService } from './log.service';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { question } from './model/question.interface';

@Injectable({
  providedIn: 'root'
})
export class QuestionDataService {
  questions: question[] = [];
  
  constructor(private logService: LogService, private http: HttpClient){

  }

  addToQuestionList(question,answer) {
    this.questions.push({
      id: 1,
      question: question,
      answer: answer
    });
    this.logService.log();
  }

  getQuestions(id): question{
    return this.questions[id];
  }

  getAllQuestions() {
    return this.http.get<question[]>('/assets/questions.json')
  }

}
