import { Component, OnInit } from '@angular/core';
import { FormArray, FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  genders = ['male', 'female'];
  signupForm: FormGroup;

  restrictedUserName = 'Test';

  ngOnInit() {
    this.signupForm = new FormGroup({
      userData: new FormGroup({
        username: new FormControl(null,[Validators.required],this.restrictUserName.bind(this)),
        email: new FormControl('null@test.com',[Validators.required, Validators.email])
      },[Validators.required]), 
      hobbies: new FormArray([]),
      gender: new FormControl('female')
    })

    console.log(this.signupForm);
   
  }

  onSubmit() {
    console.log(this.signupForm);
  }

  addHobbies(){
    const hobbieControl = new FormControl();
    (<FormArray>this.signupForm.get('hobbies')).push(hobbieControl);
  }

  restrictUserName() {
    const promise = new Promise((resolve, reject)=> {
      setTimeout(()=>{
        debugger;
        if(this.signupForm.get('userData.username').value !== this.restrictedUserName){
          resolve(null);
        } else {
          resolve({'restrictedUserName': true});
        }
          
      },3000);
    });
    return promise;
  }
}
