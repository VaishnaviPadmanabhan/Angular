import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from '../app.service';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs';
import { map,filter,first } from 'rxjs/operators';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit, OnDestroy{
  sub: Subscription;

  constructor(private router: Router, private appservice: AppService) { }

  ngOnInit(): void {
    const newObservable = Observable.create(data => {
      
      let count = 0;
      setInterval(()=>{
        data.next(count);
        /* if(count > 3) {
          data.error(new Error('Count is greater than 3'));
        }

        if(count > 2) {
          data.complete();
        } */
        count = count+ 1;
      },2000)
    });

    this.sub = newObservable.pipe(first((data)=>{
      return data > 1;
    }),map((data)=>{
      return 'Round - ' + data;
    })).subscribe(next=> {
      console.log(next);
    }, error=> {
        console.log(error);
    }, ()=> {
      alert('Process Completed!')
    })

  }

  showServer(bol) {
    //logic
    if(bol) {
      this.router.navigate(['/servers']); 
    } else {
      this.router.navigate(['/newservers']);
    }
  }

  ngOnDestroy() {
    this.sub.unsubscribe();
  }

  login() {
    this.appservice.login();
    alert('Login Success');
  }

  logout() {
    this.appservice.logout();
    alert('Logout Success');
  }

}
