import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { NewServerComponent } from './new-server/new-server.component';
import { ServerListComponent } from './server-list/server-list.component';
import { HomeComponent } from './home/home.component';
import { NotfoundComponent } from './notfound/notfound.component';
import { SingleServerComponent } from './singleserver/singleserver.component';
import { AuthGaurd } from './auth-gaurd.service';
import { ServerResolver } from './server-resolver.service';


const approutes: Routes = [
  {path: '', component: HomeComponent}, //localhost:4200
  {path: 'servers', component: ServerListComponent, canActivateChild: [AuthGaurd],  children: [
    {path: ':id', component: SingleServerComponent,resolve: {server: ServerResolver}}, //localhost:4200/servers/1 , servers/2, servers/something
  ]}, //localhost:4200/servers
  {path: 'newservers', component: NewServerComponent,  canDeactivate: [AuthGaurd]},//localhost:4200/newservers
  {path: '**', component: NotfoundComponent, data: {message: 'Page not found 404 error!'}}
]

@NgModule({
  imports: [
    RouterModule.forRoot(approutes)
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
