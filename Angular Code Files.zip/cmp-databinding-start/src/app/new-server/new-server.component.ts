import { Component, OnInit, EventEmitter, Output, ViewChild } from '@angular/core';
import { AppService } from '../app.service';
import { ServerDataService } from '../server-data.service';

@Component({
  selector: 'app-new-server',
  templateUrl: './new-server.component.html',
  styleUrls: ['./new-server.component.css'],
  providers: [AppService]
})
export class NewServerComponent implements OnInit {
  /* newServerName = '';
  newServerContent = ''; */

  /* @Output('sc') serverCreated = new EventEmitter<{type: string, name: string,content: string}>();
  @Output('bc') blueprintCreated = new EventEmitter<{type: string, name: string,content: string}>(); */

  @ViewChild('servername') serverName;
  @ViewChild('servercontent') serverContent;
  @ViewChild('serverid') serverId;

  constructor(private appservice: AppService, private serverdata: ServerDataService) { }

  ngOnInit(): void {
  }

  onAddServer() {
    /* this.serverElements.push({
      type: 'server',
      name: this.newServerName,
      content: this.newServerContent
    }); */
    
    /* this.serverCreated.emit({
      type: 'server',
      name: this.serverName.nativeElement.value,
      content: this.serverContent.nativeElement.value
    }); */
    this.serverdata.onAddServer(this.serverId.nativeElement.value,'server',this.serverName.nativeElement.value,this.serverContent.nativeElement.value);
    this.appservice.logServers();
  }
  

  onAddBlueprint() {
    /* this.serverElements.push({
      type: 'blueprint',
      name: this.newServerName,
      content: this.newServerContent
    }); */
    /* this.blueprintCreated.emit({
      type: 'blueprint',
      name: this.serverName.nativeElement.value,
      content: this.serverContent.nativeElement.value
    }); */
    this.serverdata.onAddBlueprint(this.serverId.nativeElement.value,'server',this.serverName.nativeElement.value,this.serverContent.nativeElement.value);
  }

  checkChanges() {
    debugger;
    if(this.serverId.nativeElement.value && this.serverName.nativeElement.value && this.serverContent.nativeElement.value) {
      return confirm('Do you want to discard the changes?');
    } else {
      return true;
    }
  }

}
