import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { ServerDataService } from '../server-data.service';

@Component({
  selector: 'app-singleserver',
  templateUrl: './singleserver.component.html',
  styleUrls: ['./singleserver.component.css']
})
export class SingleServerComponent implements OnInit {

  server: {serverId: number, name: string,content: string};

  constructor(private dataservice: ServerDataService,private router: Router,private activeroute: ActivatedRoute) { }

  ngOnInit(): void {
    /* this.server = this.dataservice.getServerDetails(+this.activeroute.snapshot.params['id']);
    console.log(this.activeroute.snapshot.queryParams['edit']);
    console.log(this.activeroute.snapshot.queryParams['status']); */
    /* this.activeroute.params.subscribe((param: Params)=>{
       this.server = this.dataservice.getServerDetails(+param['id']);
    }) */
    
    this.activeroute.queryParams.subscribe((param: Params)=> {
      console.log(param['edit']);
    }, error => {

    }, ()=> {
      
    }) 

    this.activeroute.data.subscribe((data)=>{
      this.server = data['server'];
    });

   
  }


  loadServer(id) {
    this.router.navigate(['/servers',id],{queryParams: {edit: false, mode: 'on'}, queryParamsHandling: 'merge'});
  }


}
