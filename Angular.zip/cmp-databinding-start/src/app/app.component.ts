import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { AppService } from './app.service';
import { ServerDataService } from './server-data.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  encapsulation: ViewEncapsulation.None,
  providers: [ServerDataService]
})
export class AppComponent implements OnInit{
  serverElements = [];

  constructor(private serverdata: ServerDataService) {

  }

  ngOnInit() {
    this.serverElements = this.serverdata.serverElements;
  }
  
}
