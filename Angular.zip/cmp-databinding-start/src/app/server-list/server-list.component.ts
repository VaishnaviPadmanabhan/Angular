import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ServerDataService } from '../server-data.service';

@Component({
  selector: 'app-server-list',
  templateUrl: './server-list.component.html',
  styleUrls: ['./server-list.component.css'],
  providers: []
})
export class ServerListComponent implements OnInit {
  //@Input('srcElement') element: { type: string, name: string, content: string };
  serverElements = [];

  constructor(private serverdata: ServerDataService, private router: Router, private activeroute: ActivatedRoute) {

  }

  ngOnInit() {
    this.serverElements = this.serverdata.serverElements;
  }

  reloadServers() {
    this.router.navigate(['list'], {relativeTo: this.activeroute}); //localhost:4200/servers/list
  }
/* 
  getServerDetails(id: number) {
    this.router.navigate(['/servers',id],{queryParams: {edit: true, status: 'online'}}); 
  } */

}
