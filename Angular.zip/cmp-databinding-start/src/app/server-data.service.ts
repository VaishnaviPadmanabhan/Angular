import { Injectable } from "@angular/core";
import { root } from "rxjs/internal/util/root";
import { AppService } from "./app.service";


@Injectable({
  providedIn: root
})
export class ServerDataService {
    serverElements = [{
        serverId: 1,
        type: 'server',
        name: 'Test Server1',
        content: 'Test Server1 Content'
    },{
      serverId: 2,
      type: 'server',
      name: 'Test Server2',
      content: 'Test Server2 Content'
  }];

    constructor(private appservice: AppService){

    }
  
    onAddServer(id: number,type: string, name: string, content: string) {
      this.serverElements.push({
        serverId: id,
        type: type,
        name: name,
        content: content
      });
      this.appservice.logServers();
    }
    
  
    onAddBlueprint(id: number,type: string, name: string, content: string) {
      this.serverElements.push({
        serverId: id,
        type: type,
        name: name,
        content: content
      });
    }

    getServerDetails(id: number) {
       for(let el of this.serverElements) {
         if(el.serverId === id){
           return el;
         }
       }
    }
}