import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { NewServerComponent } from './new-server/new-server.component';
import { ServerListComponent } from './server-list/server-list.component';
import { HomeComponent } from './home/home.component';
import { AppService } from './app.service';
import { NotfoundComponent } from './notfound/notfound.component';
import { SingleServerComponent } from './singleserver/singleserver.component';
import { AppRoutingModule } from './app-routing.module';
import { AuthGaurd } from './auth-gaurd.service';
import { ServerResolver } from './server-resolver.service';
import { ServerDataService } from './server-data.service';

/* 
const approutes: Routes = [
  {path: '', component: HomeComponent}, //localhost:4200
  {path: 'servers', component: ServerListComponent, children: [
    {path: ':id', component: SingleServerComponent}, //localhost:4200/servers/1 , servers/2, servers/something
  ]}, //localhost:4200/servers
  {path: 'newservers', component: NewServerComponent},//localhost:4200/newservers
  {path: '**', redirectTo: ''}
] */

@NgModule({
  declarations: [
    AppComponent,
    NewServerComponent,
    ServerListComponent,
    HomeComponent,
    NotfoundComponent,
    SingleServerComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule
  ],
  providers: [AppService, AuthGaurd, ServerResolver, ServerDataService],
  bootstrap: [AppComponent]
})
export class AppModule { }
