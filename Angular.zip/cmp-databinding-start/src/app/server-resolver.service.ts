import { Injectable } from "@angular/core";
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot } from "@angular/router";
import { Observable } from "rxjs/Observable";
import { ServerDataService } from "./server-data.service";

interface server {
    serverId: number;
    type: string;
    name: string;
    content: string;
}

@Injectable()
export class ServerResolver implements Resolve<server>{
    constructor(private serverdata: ServerDataService) {
        
    }

    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<server> | Promise<server> | server {
        return this.serverdata.getServerDetails(+route.params['id']);
    }
}