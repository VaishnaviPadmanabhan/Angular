
export class AppService {
    loggedIn: boolean = false;
    
    logServers() {
        console.log('New Server was added!');
    }

    isAuthenticated() {
        const promise = new Promise((resolve,reject)=>{
            setTimeout(()=>{
                resolve(this.loggedIn)
            }, 500);
        });
        return promise;
    }

    login() {
        this.loggedIn = true;
    }
  
    logout() {
      this.loggedIn = false;
    }


}