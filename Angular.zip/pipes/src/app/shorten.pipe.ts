import { Pipe, PipeTransform } from "@angular/core";


@Pipe({
    name: 'shorten'
})
export class ShortenPipe implements PipeTransform{
    transform(value: any, strLength: number){
        if(value.length === strLength ){
            return value;
        }
        return value.substr(0, strLength) + ' ...';
    }

}